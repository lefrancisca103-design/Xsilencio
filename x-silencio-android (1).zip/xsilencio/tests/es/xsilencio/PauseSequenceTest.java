package es.xsilencio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Runs with a plain JDK: no Android runtime or test libraries required. */
public final class PauseSequenceTest {
    private static final class Task {
        final Runnable runnable;
        final long time;
        boolean removed;
        boolean executed;
        Task(Runnable runnable, long time) { this.runnable = runnable; this.time = time; }
    }

    private static final class Clock implements PauseSequence.Dispatcher {
        long now;
        final List<Task> tasks = new ArrayList<>();
        public void postDelayed(Runnable runnable, long delay) { tasks.add(new Task(runnable, now + delay)); }
        public void removeCallbacks(Runnable runnable) {
            for (Task task : tasks) if (task.runnable == runnable) task.removed = true;
        }
        void advance(long time) {
            if (time < now) throw new AssertionError("Clock cannot move backwards");
            while (true) {
                Task next = null;
                for (Task task : tasks) {
                    if (!task.removed && !task.executed && task.time <= time &&
                            (next == null || task.time < next.time)) next = task;
                }
                if (next == null) break;
                now = next.time;
                next.executed = true;
                next.runnable.run();
            }
            now = time;
        }
    }

    private static final class Fixture {
        final Clock clock = new Clock();
        boolean master = true;
        boolean outside = true;
        boolean session;
        final List<Long> times = new ArrayList<>();
        final List<Long> pauses = new ArrayList<>();
        final List<String> reasons = new ArrayList<>();
        final List<Integer> numbers = new ArrayList<>();
        final PauseSequence sequence = new PauseSequence(clock,
                manual -> master && (manual || outside),
                (reason, number) -> {
                    times.add(clock.now);
                    reasons.add(reason);
                    numbers.add(number);
                    if (session) pauses.add(clock.now);
                });
    }

    private static void equal(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": expected=" + expected + ", actual=" + actual);
    }

    private static void lateSession() {
        Fixture f = new Fixture();
        f.sequence.request("exit", false);
        f.clock.advance(0);
        equal(0, f.pauses.size(), "First attempt has no session");
        f.clock.advance(299);
        f.session = true;
        f.clock.advance(300);
        equal(Arrays.asList(300L), f.pauses, "A session arriving later must be paused");
    }

    private static void returnToX() {
        Fixture f = new Fixture();
        f.sequence.request("exit", false);
        f.clock.advance(0);
        f.outside = false;
        f.clock.advance(10000);
        equal(Arrays.asList(0L), f.times, "Returning to X cancels remaining attempts");
    }

    private static void revokeMaster() {
        Fixture f = new Fixture();
        f.sequence.request("manual", true);
        f.clock.advance(300);
        f.master = false;
        f.clock.advance(10000);
        equal(Arrays.asList(0L, 300L), f.times, "Master switch also stops manual retries");
    }

    private static void coalesceCallbacks() {
        Fixture f = new Fixture();
        f.sequence.request("first", false);
        f.clock.advance(100);
        f.sequence.request("callback", false);
        f.clock.advance(3500);
        equal(Arrays.asList(0L, 300L, 900L, 1800L, 3500L), f.times, "Callbacks must not reset or multiply retries");
        equal(Arrays.asList("first", "first", "first", "first", "first"), f.reasons, "Original reason is retained");
        equal(Arrays.asList(1, 2, 3, 4, 5), f.numbers, "Attempt numbers are one based");
    }

    private static void afterExhaustion() {
        Fixture f = new Fixture();
        f.sequence.request("first", false);
        f.clock.advance(3500);
        f.sequence.request("next", false);
        f.clock.advance(7000);
        equal(Arrays.asList(0L, 300L, 900L, 1800L, 3500L, 3500L, 3800L, 4400L, 5300L, 7000L),
                f.times, "A new sequence must work immediately after exhaustion");
        equal(1, f.numbers.get(5), "Attempt numbering restarts");
    }

    private static void obsoleteCallback() {
        Fixture f = new Fixture();
        f.sequence.request("old", false);
        Runnable old = f.clock.tasks.get(0).runnable;
        f.sequence.cancel();
        f.sequence.request("new", false);
        old.run(); // Simulate a callback delivered despite removeCallbacks.
        f.clock.advance(0);
        equal(Arrays.asList("new"), f.reasons, "An obsolete generation must never execute");
        for (int i = 0; i < 5; i++) {
            equal(true, f.clock.tasks.get(i).removed, "Cancel removes every pending callback");
        }
    }

    private static void manualPriority() {
        Fixture f = new Fixture();
        f.sequence.request("auto", false);
        f.clock.advance(0);
        f.clock.advance(100);
        f.outside = false;
        f.sequence.request("manual", true);
        f.sequence.request("ignored auto", false);
        f.clock.advance(3600);
        equal(Arrays.asList(0L, 100L, 400L, 1000L, 1900L, 3600L), f.times, "Manual replaces auto; auto cannot replace manual");
        equal(Arrays.asList("auto", "manual", "manual", "manual", "manual", "manual"), f.reasons,
                "Manual requests remain allowed inside X");
    }

    public static void main(String[] args) {
        lateSession();
        returnToX();
        revokeMaster();
        coalesceCallbacks();
        afterExhaustion();
        obsoleteCallback();
        manualPriority();
        System.out.println("PauseSequenceTest: 7 tests passed");
    }
}
