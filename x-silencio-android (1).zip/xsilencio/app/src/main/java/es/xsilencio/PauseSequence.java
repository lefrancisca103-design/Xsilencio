package es.xsilencio;

/** All calls, including dispatcher callbacks, must run on the same thread. */
final class PauseSequence {
    interface Dispatcher {
        void postDelayed(Runnable callback, long delay);
        void removeCallbacks(Runnable callback);
    }
    interface Gate { boolean allowed(boolean manual); }
    interface Attempt { void run(String reason, int attempt); }

    private static final long[] OFFSETS = {0, 300, 900, 1800, 3500};
    private final Dispatcher dispatcher;
    private final Gate gate;
    private final Attempt attempt;
    private final Runnable[] pending = new Runnable[OFFSETS.length];
    private long generation;
    private boolean active;

    PauseSequence(Dispatcher dispatcher, Gate gate, Attempt attempt) {
        this.dispatcher = dispatcher;
        this.gate = gate;
        this.attempt = attempt;
    }

    void request(String reason, boolean manual) {
        if (active && !manual) return;
        cancel();
        active = true;
        final long expected = generation;
        for (int i = 0; i < OFFSETS.length; i++) {
            final int index = i;
            Runnable callback = () -> {
                if (!active || generation != expected) return;
                pending[index] = null;
                if (!gate.allowed(manual)) {
                    cancel();
                    return;
                }
                if (!active || generation != expected) return;
                attempt.run(reason, index + 1);
                if (generation == expected && index == OFFSETS.length - 1) active = false;
            };
            pending[i] = callback;
            dispatcher.postDelayed(callback, OFFSETS[i]);
        }
    }

    void cancel() {
        generation++;
        active = false;
        for (int i = 0; i < pending.length; i++) {
            if (pending[i] != null) dispatcher.removeCallbacks(pending[i]);
            pending[i] = null;
        }
    }
}
