package es.xsilencio;
import android.content.Context;
final class Rule {
    static final String X = "com.twitter.android";
    static volatile boolean foreground = false;
    static volatile boolean foregroundKnown = false;
    static volatile long outsideSince;
    static boolean enabled(Context c, String key) { return c.getSharedPreferences("rules", 0).getBoolean(key, true); }
    static void set(Context c, String key, boolean value) { c.getSharedPreferences("rules", 0).edit().putBoolean(key, value).apply(); }
}
