package es.xsilencio;
import android.app.KeyguardManager;
import android.content.*;
import android.media.session.*;
import android.os.*;
import android.service.notification.NotificationListenerService;
import java.util.*;
public class XListener extends NotificationListenerService {
    static volatile XListener instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaSessionManager manager;
    private final List<MediaController> watched = new ArrayList<>();
    private long lastPause;
    private boolean registered;
    private final MediaController.Callback callback = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState state) { if (shouldPause()) pause("Reproducción fuera de X"); }
    };
    private final MediaSessionManager.OnActiveSessionsChangedListener sessions = list -> watch(list);
    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Rule.enabled(c, "lock") && Rule.enabled(c, "master")) {
                pause("Pantalla apagada");
                handler.postDelayed(() -> { if (shouldPause()) pause("Pantalla bloqueada"); }, 1000);
            }
        }
    };
    @Override public void onListenerConnected() {
        instance = this;
        manager = getSystemService(MediaSessionManager.class);
        try {
            manager.addOnActiveSessionsChangedListener(sessions, new ComponentName(this, XListener.class), handler);
            IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screen, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(screen, f);
            registered = true;
            watch(manager.getActiveSessions(new ComponentName(this, XListener.class)));
        } catch (SecurityException e) { record("Falta acceso a notificaciones"); }
    }
    private boolean shouldPause() {
        PowerManager power = getSystemService(PowerManager.class);
        KeyguardManager keyguard = getSystemService(KeyguardManager.class);
        boolean locked = !power.isInteractive() || keyguard.isKeyguardLocked();
        return Rule.enabled(this, "master") && ((locked && Rule.enabled(this, "lock")) ||
            (XAccessibility.connected && !Rule.foreground && Rule.enabled(this, "exit")));
    }
    private void watch(List<MediaController> list) {
        for (MediaController c : watched) c.unregisterCallback(callback);
        watched.clear();
        if (list != null) for (MediaController c : list) if (Rule.X.equals(c.getPackageName())) { watched.add(c); c.registerCallback(callback, handler); }
        if (shouldPause()) pause("Sesión de X en segundo plano");
    }
    static boolean pauseNow(String reason) {
        XListener s = instance;
        if (s == null) return false;
        s.handler.post(() -> s.pause(reason));
        return true;
    }
    private void pause(String reason) {
        if (!Rule.enabled(this, "master") || manager == null) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastPause < 700) return;
        lastPause = now;
        int sent = 0;
        try {
            for (MediaController c : manager.getActiveSessions(new ComponentName(this, XListener.class))) {
                if (!Rule.X.equals(c.getPackageName())) continue;
                PlaybackState state = c.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PAUSED) continue;
                c.getTransportControls().pause();
                sent++;
            }
            record(sent > 0 ? reason + ": orden de pausa enviada a X" : "No hay una sesión de X que pausar");
        } catch (SecurityException e) { record("Activa de nuevo el acceso a notificaciones"); }
    }
    private void record(String text) { getSharedPreferences("rules", 0).edit().putString("last", text).apply(); }
    @Override public void onListenerDisconnected() { cleanup(); }
    private void cleanup() {
        instance = null;
        handler.removeCallbacksAndMessages(null);
        for (MediaController c : watched) c.unregisterCallback(callback);
        watched.clear();
        if (manager != null) manager.removeOnActiveSessionsChangedListener(sessions);
        if (registered) { unregisterReceiver(screen); registered = false; }
    }
    @Override public void onDestroy() { cleanup(); super.onDestroy(); }
}
