package es.xsilencio;

import android.app.KeyguardManager;
import android.content.*;
import android.media.session.*;
import android.os.*;
import android.service.notification.NotificationListenerService;
import android.view.KeyEvent;
import java.text.DateFormat;
import java.util.*;

public class XListener extends NotificationListenerService {
    static volatile XListener instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaSessionManager manager;
    private final List<MediaController> watched = new ArrayList<>();
    private PauseSequence sequence;
    private boolean registered;
    private boolean listening;
    private boolean destroyed;
    private final Runnable confirmExit = () -> requestAutomatic("Salida de X");

    private final MediaController.Callback callback = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState state) {
            if (state != null && isPlaying(state)) requestAutomatic("X volvió a reproducirse");
        }
        @Override public void onSessionDestroyed() { handler.post(() -> refreshSessions()); }
    };
    private final MediaSessionManager.OnActiveSessionsChangedListener sessions = this::watch;
    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) requestAutomatic("Pantalla apagada");
            else if (shouldPause()) requestAutomatic("Comprobar protección");
            else if (sequence != null) sequence.cancel();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        sequence = new PauseSequence(new PauseSequence.Dispatcher() {
            @Override public void postDelayed(Runnable r, long delay) { handler.postDelayed(r, delay); }
            @Override public void removeCallbacks(Runnable r) { handler.removeCallbacks(r); }
        }, manual -> !destroyed && listening && Rule.enabled(this, "master") && (manual || shouldPause()), this::attemptPause);
    }

    @Override public void onListenerConnected() {
        cleanup();
        listening = true;
        instance = this;
        manager = getSystemService(MediaSessionManager.class);
        try {
            manager.addOnActiveSessionsChangedListener(sessions, new ComponentName(this, XListener.class), handler);
            IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
            f.addAction(Intent.ACTION_SCREEN_ON);
            f.addAction(Intent.ACTION_USER_PRESENT);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screen, f, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(screen, f);
            registered = true;
            refreshSessions();
        } catch (SecurityException e) {
            record("Falta acceso a notificaciones");
            cleanup();
        }
    }

    private boolean shouldPause() {
        if (!Rule.enabled(this, "master")) return false;
        PowerManager power = getSystemService(PowerManager.class);
        KeyguardManager keyguard = getSystemService(KeyguardManager.class);
        boolean locked = !power.isInteractive() || keyguard.isKeyguardLocked();
        return (locked && Rule.enabled(this, "lock")) ||
            (!locked && XAccessibility.connected && Rule.foregroundKnown && !Rule.foreground &&
                SystemClock.elapsedRealtime() - Rule.outsideSince >= 350 && Rule.enabled(this, "exit"));
    }

    private static boolean isPlaying(PlaybackState s) {
        int value = s.getState();
        return value == PlaybackState.STATE_PLAYING || value == PlaybackState.STATE_BUFFERING ||
            value == PlaybackState.STATE_CONNECTING || value == PlaybackState.STATE_FAST_FORWARDING ||
            value == PlaybackState.STATE_REWINDING || value == PlaybackState.STATE_SKIPPING_TO_NEXT ||
            value == PlaybackState.STATE_SKIPPING_TO_PREVIOUS || value == PlaybackState.STATE_SKIPPING_TO_QUEUE_ITEM;
    }

    private void refreshSessions() {
        if (!listening || manager == null) return;
        try { watch(manager.getActiveSessions(new ComponentName(this, XListener.class))); }
        catch (SecurityException e) { record("Activa de nuevo el acceso a notificaciones"); }
    }

    private void watch(List<MediaController> list) {
        for (MediaController c : watched) c.unregisterCallback(callback);
        watched.clear();
        if (list != null) for (MediaController c : list) {
            if (Rule.X.equals(c.getPackageName())) {
                watched.add(c);
                c.registerCallback(callback, handler);
            }
        }
        if (!watched.isEmpty()) requestAutomatic("Sesión de X fuera de pantalla");
    }

    private void requestAutomatic(String reason) {
        if (sequence != null && listening && shouldPause()) sequence.request(reason, false);
    }

    static void foregroundChanged() {
        XListener s = instance;
        if (s == null) return;
        s.handler.post(() -> {
            if (!s.listening) return;
            s.handler.removeCallbacks(s.confirmExit);
            s.sequence.cancel();
            // Recheck after the window settles, including permission/rule changes.
            // Playback/session callbacks use the same settle interval in shouldPause().
            s.handler.postDelayed(s.confirmExit, 350);
        });
    }

    static void rulesChanged() { foregroundChanged(); }

    static boolean pauseNow(String reason) {
        XListener s = instance;
        if (s == null || !s.listening || !Rule.enabled(s, "master")) return false;
        s.handler.post(() -> s.sequence.request(reason, true));
        return true;
    }

    private void attemptPause(String reason, int attempt) {
        int found = 0;
        int sent = 0;
        int idle = 0;
        try {
            // X may publish its session only after Home appears; query again on every retry.
            for (MediaController c : manager.getActiveSessions(new ComponentName(this, XListener.class))) {
                if (!Rule.X.equals(c.getPackageName())) continue;
                found++;
                PlaybackState state = c.getPlaybackState();
                if (state != null && (state.getState() == PlaybackState.STATE_PAUSED || state.getState() == PlaybackState.STATE_STOPPED)) {
                    idle++;
                }
                // PAUSE is idempotent. Do not trust a stale PAUSED report enough to skip it.
                c.getTransportControls().pause();
                if (attempt >= 3) {
                    // A PAUSE key addressed to this session; never a global media key or toggle.
                    long time = SystemClock.uptimeMillis();
                    c.dispatchMediaButtonEvent(new KeyEvent(time, time, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
                    c.dispatchMediaButtonEvent(new KeyEvent(time, time, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
                }
                sent++;
            }
            String result = sent > 0 ? (idle == found ? "X informa que está pausado; pausa enviada de nuevo" : "orden de pausa enviada a X") :
                found == 0 ? "X todavía no publica una sesión multimedia" :
                idle == found ? "X informa que está pausado" : "sin orden enviada";
            record(reason + " · intento " + attempt + ": " + result);
        } catch (SecurityException e) {
            sequence.cancel();
            record("Activa de nuevo el acceso a notificaciones");
        }
    }

    private void record(String text) {
        String stamp = DateFormat.getTimeInstance(DateFormat.MEDIUM).format(new Date());
        getSharedPreferences("rules", 0).edit().putString("last", stamp + " · " + text).apply();
    }

    @Override public void onListenerDisconnected() {
        cleanup();
        if (!destroyed && Rule.enabled(this, "master")) {
            try { requestRebind(new ComponentName(this, XListener.class)); }
            catch (SecurityException ignored) { record("Multimedia desconectada: revisa los permisos"); }
        }
    }

    private void cleanup() {
        listening = false;
        if (instance == this) instance = null;
        if (sequence != null) sequence.cancel();
        handler.removeCallbacksAndMessages(null);
        for (MediaController c : watched) c.unregisterCallback(callback);
        watched.clear();
        if (manager != null) manager.removeOnActiveSessionsChangedListener(sessions);
        if (registered) { unregisterReceiver(screen); registered = false; }
    }

    @Override public void onDestroy() { destroyed = true; cleanup(); super.onDestroy(); }
}
