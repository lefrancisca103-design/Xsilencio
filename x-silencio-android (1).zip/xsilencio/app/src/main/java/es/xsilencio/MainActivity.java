package es.xsilencio;
import android.app.*;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
public class MainActivity extends Activity {
    private LinearLayout column;
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        column = new LinearLayout(this); column.setOrientation(1); column.setPadding(48,64,48,48); column.setBackgroundColor(Color.rgb(245,247,250));
        scroll.addView(column); setContentView(scroll);
        text("X Silencio · 1.1", 32);
        text("Tu audio, cuando tú quieras", 19);
        text("Pausa los vídeos de X al salir o apagar la pantalla. No necesita tu cuenta de X ni conexión a Internet.", 16);
        toggle("Protección activada", "master");
        text("Este interruptor controla todas las reglas. Si lo apagas, X Silencio no pausará el audio al salir ni al bloquear.", 14);
        toggle("Pausar al salir de X", "exit");
        toggle("Pausar al apagar o bloquear la pantalla", "lock");
        text("Configuración inicial", 22);
        text("1. El acceso a notificaciones permite controlar la sesión multimedia de X. Android concede acceso amplio a notificaciones; esta app no lee su contenido.", 15);
        button("Abrir acceso a notificaciones", v -> open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        text("2. Accesibilidad detecta cuándo cambias de aplicación. Solo usa el nombre de la app; no lee la pantalla ni realiza gestos. Es opcional si solo quieres pausar al bloquear.", 15);
        button("Configurar accesibilidad", v -> new AlertDialog.Builder(this).setTitle("Detectar salida de X").setMessage("Al activar X Silencio en Accesibilidad, autorizas que detecte la aplicación de los eventos de ventana. Los datos se procesan en el teléfono y no se guardan ni se comparten. Puedes desactivarlo en cualquier momento.").setNegativeButton("Cancelar", null).setPositiveButton("Continuar", (d,w) -> open(Settings.ACTION_ACCESSIBILITY_SETTINGS)).show());
        button("Probar: pausar X ahora", v -> {
            boolean ready = XListener.pauseNow("Prueba manual");
            Toast.makeText(this, ready ? "Prueba solicitada. Comprueba si se detiene X." : "Activa la protección y el acceso a notificaciones", Toast.LENGTH_LONG).show();
            column.postDelayed(this::refresh, 1000);
        });
        status = text("", 15);
        text("La pausa depende de que X publique una sesión multimedia y acepte la orden. No fuerza el cierre de X. El ahorro de batería del fabricante puede interrumpir la detección. Algunas ventanas del sistema o el modo multiventana pueden afectar a la detección de salida.", 14);
    }
    @Override protected void onResume() { super.onResume(); refresh(); }
    private void refresh() { if (status != null) status.setText("Multimedia: " + (XListener.instance != null ? "conectada" : "pendiente") + "\nDetección de salida: " + (XAccessibility.connected ? "conectada" : "pendiente") + "\nÚltimo resultado: " + getSharedPreferences("rules",0).getString("last", "sin pruebas todavía")); }
    private TextView text(String value, int size) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.rgb(23,35,50)); t.setPadding(0,12,0,16); column.addView(t); return t; }
    private void toggle(String label, String key) { Switch s = new Switch(this); s.setText(label); s.setTextSize(17); s.setPadding(0,22,0,22); s.setChecked(Rule.enabled(this,key)); s.setOnCheckedChangeListener((v,on) -> { Rule.set(this,key,on); XListener.rulesChanged(); }); column.addView(s); }
    private void button(String label, View.OnClickListener listener) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(listener); column.addView(b); }
    private void open(String action) { try { startActivity(new Intent(action)); } catch (android.content.ActivityNotFoundException e) { Toast.makeText(this,"Abre este permiso desde los ajustes de Android",Toast.LENGTH_LONG).show(); } }
}
