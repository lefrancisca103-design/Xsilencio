package es.xsilencio;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
public class XAccessibility extends AccessibilityService {
    static volatile boolean connected;
    @Override protected void onServiceConnected() { connected = true; Rule.foreground = false; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName() == null) return;
        String name = e.getPackageName().toString();
        // Notification shade and keyboard windows are not evidence of leaving X.
        if (name.equals("com.android.systemui") || name.contains("inputmethod") || name.contains("keyboard")) return;
        boolean wasX = Rule.foreground;
        Rule.foreground = Rule.X.equals(name);
        if (wasX && !Rule.foreground && Rule.enabled(this, "exit")) XListener.pauseNow("Salida de X");
    }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { connected = false; Rule.foreground = false; super.onDestroy(); }
}
