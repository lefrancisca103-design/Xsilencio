package es.xsilencio;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import java.util.HashSet;
import java.util.Set;

public class XAccessibility extends AccessibilityService {
    static volatile boolean connected;
    private final Set<String> launchers = new HashSet<>();

    @Override protected void onServiceConnected() {
        connected = true;
        // A reconnection does not tell us which app is currently on screen.
        Rule.foregroundKnown = false;
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        launchers.clear();
        for (ResolveInfo info : getPackageManager().queryIntentActivities(home, 0)) {
            if (info.activityInfo != null) launchers.add(info.activityInfo.packageName);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (Rule.X.equals(pkg)) {
            setForeground(true);
            return;
        }
        if (pkg.equals("android") || pkg.equals("com.android.systemui") || isKeyboard(pkg)) return;
        // A keyboard, popup or other overlay is not evidence of leaving X.
        // Home or an actual Activity window provides a stronger signal.
        if (launchers.contains(pkg) || isActivity(pkg, event.getClassName())) setForeground(false);
    }

    private boolean isKeyboard(String pkg) {
        InputMethodManager input = getSystemService(InputMethodManager.class);
        if (input != null) for (InputMethodInfo info : input.getEnabledInputMethodList()) {
            if (pkg.equals(info.getPackageName())) return true;
        }
        return false;
    }

    private boolean isActivity(String pkg, CharSequence name) {
        if (name == null) return false;
        String activity = name.toString();
        if (activity.startsWith(".")) activity = pkg + activity;
        try {
            getPackageManager().getActivityInfo(new ComponentName(pkg, activity), 0);
            return true;
        } catch (PackageManager.NameNotFoundException | SecurityException ignored) {
            return false;
        }
    }

    private void setForeground(boolean foreground) {
        boolean changed = !Rule.foregroundKnown || Rule.foreground != foreground;
        Rule.foreground = foreground;
        if (changed && !foreground) Rule.outsideSince = SystemClock.elapsedRealtime();
        Rule.foregroundKnown = true;
        if (changed) XListener.foregroundChanged();
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        connected = false;
        Rule.foregroundKnown = false;
        XListener.foregroundChanged();
        super.onDestroy();
    }
}
