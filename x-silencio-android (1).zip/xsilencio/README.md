# X Silencio — Android

## Versión 1.1: detección de salida más prudente

- Al reconectar los servicios, no se presupone que X está fuera de pantalla.
- Se distinguen los teclados habilitados de una salida real, sin consultar contenido de pantalla.
- Se espera a que Inicio u otra actividad permanezca fuera de X al menos 350 ms; volver a X cancela la comprobación y los reintentos.
- La pausa se intenta hasta cinco veces durante 3,5 segundos; las peticiones de sesión o reproducción que llegan durante ese intervalo se agrupan, sin el antiguo descarte de 700 ms.
- Las órdenes se dirigen solo a las sesiones de `com.twitter.android`. PAUSE se vuelve a enviar aunque el estado comunicado por X pueda estar desactualizado.
- La pantalla explica que apagar «Protección activada» detiene todas las pausas automáticas.

Esto aborda defectos observados en el código. No demuestra por sí solo cuál produjo el fallo en un teléfono concreto. Android y X pueden seguir imponiendo límites a la detección y a las órdenes multimedia.

### Compilar desde el móvil con el repositorio existente

Sube el ZIP de esta versión a la raíz del repositorio, conservando exactamente el nombre que utiliza tu workflow: `x-silencio-android (1).zip`. Sustituye el archivo anterior y guarda el cambio. El workflow que ya funciona volverá a compilar y publicará `X-Silencio-APK` en Actions.

El ZIP lleva pruebas independientes de la cola de pausas: el proyecto las ejecuta antes de compilar Android. Las pruebas comprueban sesiones que aparecen tarde, cancelación al volver a X, desactivación de la protección y peticiones que llegan mientras una secuencia está en marcha.

**Firma de instalación:** el workflow actual usa una clave de depuración nueva en cada ejecución. Si Android rechaza actualizar la app instalada por incompatibilidad de firma, tendrás que desinstalar la anterior e instalar esta, perdiendo los ajustes y permisos de X Silencio. El código de versión no soluciona una firma distinta. Para actualizaciones continuas habrá que guardar una clave de firma privada estable mediante GitHub Secrets.

### Validar esta versión en el teléfono

Activa Protección, salida y bloqueo. Reproduce varios vídeos seguidos en X; abrir el teclado no debería pausarlos. Pulsa Inicio: debería pausarse tras un breve intervalo. Vuelve rápidamente a X y reproduce de nuevo: los reintentos anteriores deben quedar cancelados. Apaga la protección y confirma que al salir ya no se envía pausa (comportamiento esperado). Prueba también el bloqueo y que una app de música distinta de X siga reproduciendo.

La versión 1.0 sí fue compilada mediante GitHub Actions y probada por el usuario. La 1.1 todavía necesita su nueva compilación Android y prueba en el teléfono. Aquí se puede comprobar sintaxis Java y ejecutar las pruebas de la cola con el módulo compilador de Java; no hay Android SDK y falla la conexión al proxy para descargarlo.

Comprobación local de 1.1: siete pruebas de la cola ejecutadas y aprobadas, análisis sintáctico de los seis archivos Java y validación de XML. No se ha ejecutado aquí Gradle ni comprobado tipos contra el SDK Android.

Primera versión nativa, enfocada en detener la reproducción multimedia de X al salir de la aplicación o apagar/bloquear la pantalla. Android 8.0 o posterior. No es un clon completo de MacroDroid.

## Crear el APK

1. Instala Android Studio (con JDK 17 o 21 y SDK de Android 35).
2. Abre esta carpeta como proyecto y permite sincronizar Gradle. Usa Gradle 8.11.1 si Android Studio pide seleccionar una distribución: el proyecto no incluye Gradle Wrapper.
3. Selecciona **Build > Build App Bundle(s) / APK(s) > Build APK(s)** (el nombre puede variar según Android Studio).
4. El APK de desarrollo aparecerá en `app/build/outputs/apk/debug/app-debug.apk`. Transfiérelo al teléfono e instálalo autorizando esa fuente. Para distribuir una versión estable, genera un APK firmado con tu propia clave.

## Activar

Abre X Silencio y activa acceso a notificaciones. Para pausar al cambiar de app, activa también su servicio de accesibilidad. Lee el aviso antes de concederlo. En ciertas versiones de Android, una app instalada desde un archivo necesita permitir ajustes restringidos desde su ficha de información, antes de habilitar estos servicios.

No hace falta root, una cuenta de desarrollador de X ni iniciar sesión en X Silencio. No solicita acceso a Internet. Conserva localmente los interruptores y el último resultado; no almacena notificaciones ni contenido de pantalla.

## Cómo funciona

La accesibilidad observa nombres de paquetes en eventos de cambio de ventana, sin acceder al árbol de contenido. El listener de notificaciones obtiene controladores multimedia y envía `pause()` exclusivamente a `com.twitter.android`. Escucha pantalla apagada y nuevos cambios de sesión/reproducción, para intentar volver a pausar si X comienza a reproducirse en segundo plano.

El mensaje «orden de pausa enviada» solo confirma el envío, no que X la haya obedecido. La app no mata procesos ni silencia todo el teléfono. No usa controles globales de reproducción que puedan pausar Spotify u otras apps.

## Comprobación en el teléfono (pendiente)

- Reproduce un vídeo en X y pulsa el botón de prueba: debe detenerse.
- Vuelve a reproducirlo y pulsa Inicio o abre otra app: debe pausarse con la regla de salida activa.
- Reproduce de nuevo y apaga/bloquea la pantalla: debe pausarse con la regla de bloqueo activa.
- Comprueba por separado cada interruptor y el interruptor general.
- Reproduce música en otra app: no debe recibir órdenes de esta aplicación.
- Revoca cada permiso: la app debe mostrarlo pendiente al volver a abrirla.
- Reinicia el teléfono y comprueba que Android reconecta los servicios. Según el fabricante, puede ser necesario permitir actividad en segundo plano o quitar la restricción de batería.

## Límites y validación realizada

Esta entrega contiene código fuente, **no un APK compilado ni probado en un dispositivo**. Se verificó que los XML son válidos y que las clases y servicios referenciados existen. El entorno no dispone de Android SDK/Gradle y la conexión al proxy de descarga del SDK falló, por lo que no se ha comprobado la compilación.

X debe exponer una sesión multimedia y aceptar `pause()`. Si no lo hace, esta técnica no puede garantizar el silencio. La detección de ventanas es aproximada: se ignora System UI para evitar confundir el panel de notificaciones con una salida de X; teclados, diálogos y multiventana pueden comportarse distinto por fabricante. La regla de bloqueo funciona mientras el listener esté conectado. La de salida requiere accesibilidad. No admite X Lite, navegadores ni paquetes clonados.

Para desinstalar, desactiva los servicios desde ajustes y elimina la app.
