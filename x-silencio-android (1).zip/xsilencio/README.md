# X Silencio — Android

Primera versión nativa, enfocada en detener la reproducción multimedia de X al salir de la aplicación o apagar/bloquear la pantalla. Android 8.0 o posterior. No es un clon completo de MacroDroid.

## Crear el APK

1. Instala Android Studio (con JDK 17 o 21 y SDK de Android 35).
2. Abre esta carpeta como proyecto y permite sincronizar Gradle. Usa Gradle 8.11.1 si Android Studio pide seleccionar una distribución: el proyecto no incluye Gradle Wrapper.
3. Selecciona **Build > Build App Bundle(s) / APK(s) > Build APK(s)** (el nombre puede variar según Android Studio).
4. El APK de desarrollo aparecerá en `app/build/outputs/apk/debug/app-debug.apk`. Transfiérelo al teléfono e instálalo autorizando esa fuente. Para distribuir una versión estable, genera un APK firmado con tu propia clave.

## Activar

Abre X Silencio y activa acceso a notificaciones. Para pausar al cambiar de app, activa también su servicio de accesibilidad. Lee el aviso antes de concederlo. En ciertas versiones de Android, una app instalada desde un archivo necesita permitir ajustes restringidos desde su ficha de información, antes de habilitar estos servicios.

No hace falta root, una cuenta de desarrollador de X ni iniciar sesión en X Silencio. No solicita acceso a Internet. Conserva localmente los interruptores y el último resultado; no almacena notificaciones ni contenido de pantalla.

## Cómo funciona

La accesibilidad observa nombres de paquetes en eventos de cambio de ventana, sin acceder al árbol de contenido. El listener de notificaciones obtiene controladores multimedia y envía `pause()` exclusivamente a `com.twitter.android`. Escucha pantalla apagada y nuevos cambios de sesión/reproducción, para intentar volver a pausar si X comienza a reproducirse en segundo plano.

El mensaje «orden de pausa enviada» solo confirma el envío, no que X la haya obedecido. La app no mata procesos ni silencia todo el teléfono. No usa controles globales de reproducción que puedan pausar Spotify u otras apps.

## Comprobación en el teléfono (pendiente)

- Reproduce un vídeo en X y pulsa el botón de prueba: debe detenerse.
- Vuelve a reproducirlo y pulsa Inicio o abre otra app: debe pausarse con la regla de salida activa.
- Reproduce de nuevo y apaga/bloquea la pantalla: debe pausarse con la regla de bloqueo activa.
- Comprueba por separado cada interruptor y el interruptor general.
- Reproduce música en otra app: no debe recibir órdenes de esta aplicación.
- Revoca cada permiso: la app debe mostrarlo pendiente al volver a abrirla.
- Reinicia el teléfono y comprueba que Android reconecta los servicios. Según el fabricante, puede ser necesario permitir actividad en segundo plano o quitar la restricción de batería.

## Límites y validación realizada

Esta entrega contiene código fuente, **no un APK compilado ni probado en un dispositivo**. Se verificó que los XML son válidos y que las clases y servicios referenciados existen. El entorno no dispone de Android SDK/Gradle y la conexión al proxy de descarga del SDK falló, por lo que no se ha comprobado la compilación.

X debe exponer una sesión multimedia y aceptar `pause()`. Si no lo hace, esta técnica no puede garantizar el silencio. La detección de ventanas es aproximada: se ignora System UI para evitar confundir el panel de notificaciones con una salida de X; teclados, diálogos y multiventana pueden comportarse distinto por fabricante. La regla de bloqueo funciona mientras el listener esté conectado. La de salida requiere accesibilidad. No admite X Lite, navegadores ni paquetes clonados.

Para desinstalar, desactiva los servicios desde ajustes y elimina la app.
